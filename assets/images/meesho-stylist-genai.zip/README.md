# Meesho Stylist GenAI – Personalized Fashion Assistant for Bharat

This project uses Generative AI to help sellers and buyers on platforms like Meesho describe and visualize their fashion products in local languages.

## Features
- Upload an image to generate a professional product caption using BLIP
- Translate captions into Indian regional languages using IndicTrans via Hugging Face
- Streamlit UI for easy interaction

## Tech Stack
- BLIP by Salesforce for image captioning
- HuggingFace Transformers for multilingual support
- Streamlit for frontend

## How to Run

```bash
pip install -r requirements.txt
streamlit run app/app.py
```