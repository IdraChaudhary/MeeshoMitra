import streamlit as st
from PIL import Image
from models.captioner import generate_caption
from models.translator import translate_to_hindi

st.set_page_config(page_title="Meesho Stylist GenAI", page_icon="🧵")
st.title("🧵 Meesho Brand Stylist – Powered by GenAI")

uploaded_file = st.file_uploader("Upload a product image", type=["jpg", "jpeg", "png"])
if uploaded_file:
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded Image", use_column_width=True)
    with st.spinner("Generating caption..."):
        caption = generate_caption(image)
        translation = translate_to_hindi(caption)
    st.success("Here's your AI-generated caption:")
    st.write("📝 English: ", caption)
    st.write("🌐 Hindi: ", translation)